/**
 * array game list
 */
export let Games: any = {
	"slots":[{"id":5861,"src":"\/frontend\/Default\/ico\/WickedCircusYGG.png","size":"small","tag":"hot","url":"\/game\/open\/WickedCircusYGG?api_exit=\/","orientation":0},{"id":5863,"src":"\/frontend\/Default\/ico\/IncineratorYGG.png","size":"small","tag":"hot","url":"\/game\/open\/IncineratorYGG?api_exit=\/","orientation":0},{"id":5864,"src":"\/frontend\/Default\/ico\/WildMantraYGG.png","size":"small","tag":"hot","url":"\/game\/open\/WildMantraYGG?api_exit=\/","orientation":0},{"id":5865,"src":"\/frontend\/Default\/ico\/BeautyAndBeastYGG.png","size":"small","tag":"hot","url":"\/game\/open\/BeautyAndBeastYGG?api_exit=\/","orientation":0},{"id":5866,"src":"\/frontend\/Default\/ico\/DarkJokeRizesYGG.png","size":"small","tag":"hot","url":"\/game\/open\/DarkJokeRizesYGG?api_exit=\/","orientation":0},{"id":5867,"src":"\/frontend\/Default\/ico\/ZeusVSThorYGG.png","size":"small","tag":"hot","url":"\/game\/open\/ZeusVSThorYGG?api_exit=\/","orientation":0},{"id":5868,"src":"\/frontend\/Default\/ico\/RainbowRyanYGG.png","size":"small","tag":"hot","url":"\/game\/open\/RainbowRyanYGG?api_exit=\/","orientation":0},{"id":5869,"src":"\/frontend\/Default\/ico\/AvatarsGatewayGuardiansYGG.png","size":"small","tag":"hot","url":"\/game\/open\/AvatarsGatewayGuardiansYGG?api_exit=\/","orientation":0},{"id":5870,"src":"\/frontend\/Default\/ico\/CleosHeartNG.png","size":"small","tag":"hot","url":"\/game\/open\/CleosHeartNG?api_exit=\/","orientation":0},{"id":5871,"src":"\/frontend\/Default\/ico\/CloverStonesNG.png","size":"small","tag":"hot","url":"\/game\/open\/CloverStonesNG?api_exit=\/","orientation":0},{"id":5872,"src":"\/frontend\/Default\/ico\/CrazyScientistNG.png","size":"small","tag":"hot","url":"\/game\/open\/CrazyScientistNG?api_exit=\/","orientation":0},{"id":5873,"src":"\/frontend\/Default\/ico\/DragonSevensNG.png","size":"small","tag":"hot","url":"\/game\/open\/DragonSevensNG?api_exit=\/","orientation":0},{"id":5874,"src":"\/frontend\/Default\/ico\/FortuneCashNG.png","size":"small","tag":"hot","url":"\/game\/open\/FortuneCashNG?api_exit=\/","orientation":0},{"id":5875,"src":"\/frontend\/Default\/ico\/FruitCashNG.png","size":"small","tag":"hot","url":"\/game\/open\/FruitCashNG?api_exit=\/","orientation":0},{"id":5876,"src":"\/frontend\/Default\/ico\/HitInVegasNG.png","size":"small","tag":"hot","url":"\/game\/open\/HitInVegasNG?api_exit=\/","orientation":0},{"id":5877,"src":"\/frontend\/Default\/ico\/MagicDragonsNG.png","size":"small","tag":"hot","url":"\/game\/open\/MagicDragonsNG?api_exit=\/","orientation":0},{"id":5878,"src":"\/frontend\/Default\/ico\/MagicTreeNG.png","size":"small","tag":"hot","url":"\/game\/open\/MagicTreeNG?api_exit=\/","orientation":0},{"id":5879,"src":"\/frontend\/Default\/ico\/MMALegendsNG.png","size":"small","tag":"hot","url":"\/game\/open\/MMALegendsNG?api_exit=\/","orientation":0},{"id":5880,"src":"\/frontend\/Default\/ico\/SpaceRocksNG.png","size":"small","tag":"hot","url":"\/game\/open\/SpaceRocksNG?api_exit=\/","orientation":0},{"id":5881,"src":"\/frontend\/Default\/ico\/VolcanoFruitsNG.png","size":"small","tag":"hot","url":"\/game\/open\/VolcanoFruitsNG?api_exit=\/","orientation":0},{"id":5882,"src":"\/frontend\/Default\/ico\/WildBuffaloNG.png","size":"small","tag":"hot","url":"\/game\/open\/WildBuffaloNG?api_exit=\/","orientation":0},{"id":5990,"src":"\/frontend\/Default\/ico\/VikingsGoWildYGG.png","size":"small","tag":"hot","url":"\/game\/open\/VikingsGoWildYGG?api_exit=\/","orientation":0},{"id":5994,"src":"\/frontend\/Default\/ico\/PenguinCityYGG.png","size":"small","tag":"hot","url":"\/game\/open\/PenguinCityYGG?api_exit=\/","orientation":0},{"id":6141,"src":"\/frontend\/Default\/ico\/ValleyOfGodsYGG.png","size":"small","tag":"hot","url":"\/game\/open\/ValleyOfGodsYGG?api_exit=\/","orientation":0},{"id":6148,"src":"\/frontend\/Default\/ico\/TrollsBridgeYGG.png","size":"small","tag":"hot","url":"\/game\/open\/TrollsBridgeYGG?api_exit=\/","orientation":0},{"id":6155,"src":"\/frontend\/Default\/ico\/NirvanaYGG.png","size":"small","tag":"hot","url":"\/game\/open\/NirvanaYGG?api_exit=\/","orientation":0},{"id":6162,"src":"\/frontend\/Default\/ico\/ChampionsofRomeYGG.png","size":"small","tag":"hot","url":"\/game\/open\/ChampionsofRomeYGG?api_exit=\/","orientation":0},{"id":6176,"src":"\/frontend\/Default\/ico\/BloodMoonWildsYGG.png","size":"small","tag":"hot","url":"\/game\/open\/BloodMoonWildsYGG?api_exit=\/","orientation":0},{"id":6190,"src":"\/frontend\/Default\/ico\/PumpkinSmashYGG.png","size":"small","tag":"hot","url":"\/game\/open\/PumpkinSmashYGG?api_exit=\/","orientation":0},{"id":6204,"src":"\/frontend\/Default\/ico\/HadesGigabloxYGG.png","size":"small","tag":"hot","url":"\/game\/open\/HadesGigabloxYGG?api_exit=\/","orientation":0},{"id":6211,"src":"\/frontend\/Default\/ico\/HanzosDojoYGG.png","size":"small","tag":"hot","url":"\/game\/open\/HanzosDojoYGG?api_exit=\/","orientation":0},{"id":6225,"src":"\/frontend\/Default\/ico\/HanzosDojoYGG.png","size":"small","tag":"hot","url":"\/game\/open\/HanzosDojoYGG?api_exit=\/","orientation":0}],
	"fishes":[{"id":5859,"src":"\/frontend\/Default\/ico\/MonsterFrenzyPGD.png","size":"big","tag":"new","url":"\/game\/open\/MonsterFrenzyPGD?api_exit=\/","orientation":0},{"id":5860,"src":"\/frontend\/Default\/ico\/AladdinAdventurePGD.png","size":"big","tag":"new","url":"\/game\/open\/AladdinAdventurePGD?api_exit=\/","orientation":0},{"id":5982,"src":"\/frontend\/Default\/ico\/FishHunterGhostPGD.png","size":"big","tag":"new","url":"\/game\/open\/FishHunterGhostPGD?api_exit=\/","orientation":0},{"id":5986,"src":"\/frontend\/Default\/ico\/FishHunterKingKongPGD.png","size":"big","tag":"new","url":"\/game\/open\/FishHunterKingKongPGD?api_exit=\/","orientation":0},{"id":6232,"src":"\/frontend\/Default\/ico\/FishHunterKingKongPGD.png","size":"big","tag":"new","url":"\/game\/open\/FishHunterKingKongPGD?api_exit=\/","orientation":0},{"id":6239,"src":"\/frontend\/Default\/ico\/FishHunterKingKongPGD.png","size":"big","tag":"new","url":"\/game\/open\/FishHunterKingKongPGD?api_exit=\/","orientation":0},{"id":6293,"src":"\/frontend\/Default\/ico\/FishHunterKingKongPGD.png","size":"big","tag":"new","url":"\/game\/open\/FishHunterKingKongPGD?api_exit=\/","orientation":0}],
	"firelinks":[{"id":5858,"src":"\/frontend\/Default\/ico\/UltraBlazingFireLink.png","size":"big","tag":"hot","url":"\/game\/open\/UltraBlazingFireLink?api_exit=\/","orientation":1},{"id":6057,"src":"\/frontend\/Default\/ico\/NorthShore.png","size":"big","tag":"hot","url":"\/game\/open\/NorthShore?api_exit=\/","orientation":1},{"id":6092,"src":"\/frontend\/Default\/ico\/ByTheBay.png","size":"big","tag":"hot","url":"\/game\/open\/ByTheBay?api_exit=\/","orientation":1}/*,{"id":6099,"src":"\/frontend\/Default\/ico\/ChinaStreet.png","size":"big","tag":"hot","url":"\/game\/open\/ChinaStreet?api_exit=\/","orientation":1},{"id":6106,"src":"\/frontend\/Default\/ico\/GlacierGold.png","size":"big","tag":"hot","url":"\/game\/open\/GlacierGold?api_exit=\/","orientation":1},{"id":6113,"src":"\/frontend\/Default\/ico\/OlveraStreet.png","size":"big","tag":"hot","url":"\/game\/open\/OlveraStreet?api_exit=\/","orientation":1},{"id":6120,"src":"\/frontend\/Default\/ico\/RiverWalk.png","size":"big","tag":"hot","url":"\/game\/open\/RiverWalk?api_exit=\/","orientation":1},{"id":6127,"src":"\/frontend\/Default\/ico\/Route66.png","size":"big","tag":"hot","url":"\/game\/open\/Route66?api_exit=\/","orientation":1},{"id":6134,"src":"\/frontend\/Default\/ico\/RueRoyale.png","size":"big","tag":"hot","url":"\/game\/open\/RueRoyale?api_exit=\/","orientation":1}*/]};
export function updateGames(val:any) {
	Games = val;
}

export const PAGE_SIZE_DEFAULT:{width:number, height:number} = {width:1920, height:1080};
export const WIDTH_COLUMN:number = 380;
export const MAX_COUNT_COLUMN:number = 5;

export let listImages: string[] = [
	"/images/frenzy/arrow1.png",
	"/images/frenzy/arrow2.png",
	"/images/frenzy/back.png",
	"/images/frenzy/bonus_back.png",
	"/images/frenzy/bonus_back_info.png",
	"/images/frenzy/bonus_btn.png",
	"/images/frenzy/bonus_close.png",
	"/images/frenzy/bonus_fon.png",
	"/images/frenzy/bonus_text.png",
	"/images/frenzy/bonus1.png",
	"/images/frenzy/bonus2.png",
	"/images/frenzy/down_c.png",
	"/images/frenzy/down_l.png",
	"/images/frenzy/down_r.png",
	"/images/frenzy/icon1.png",
	"/images/frenzy/icon2.png",
	"/images/frenzy/anim/hot.json",
	"/images/frenzy/anim/hot.png",
	"/images/frenzy/anim/new.json",
	"/images/frenzy/anim/new.png",
	"/images/frenzy/settings.png",
	"/images/frenzy/settings2.png",
	"/images/frenzy/top_c.png",
	"/images/frenzy/top_l.png",
	"/images/frenzy/top_r.png",
	"/images/frenzy/anim/all.png",
	"/images/frenzy/anim/all.json",
	"/images/frenzy/anim/bonus.png",
	"/images/frenzy/anim/bonus.json",
	"/images/frenzy/anim/coin.png",
	"/images/frenzy/anim/coin.json",
	"/images/frenzy/anim/fav.png",
	"/images/frenzy/anim/fav.json",
	"/images/frenzy/anim/fish.png",
	"/images/frenzy/anim/fish.json",
	"/images/frenzy/anim/logo.png",
	"/images/frenzy/anim/logo.json",
	"/images/frenzy/anim/table.png",
	"/images/frenzy/anim/table.json",
	"/images/frenzy/anim/user.json",
	"/images/frenzy/anim/user.png",
	"/images/frenzy/anim/icon.json",
	"/images/frenzy/anim/icon.png",
	"/images/frenzy/anim/trunc.json",
	"/images/frenzy/anim/trunc.png",
	"/images/frenzy/news_icon.png",
    "/images/frenzy/news_img_1.png",
	"/images/frenzy/news_img_2.png",
];